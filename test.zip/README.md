# syook-assessment

## Emitter Service
Running in port 3000

`npm run emitter`

## Listener Service
Running in port 3001

`npm run listener`

## UI
Access in bowser, http://<ip-address>:3001

## MongoDB
`mongo`

  Database name: 'syook'

  Collection name: 'messages'

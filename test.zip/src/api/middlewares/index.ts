import requestLogger from './requestLogger';


export default {

    requestLogger

}

